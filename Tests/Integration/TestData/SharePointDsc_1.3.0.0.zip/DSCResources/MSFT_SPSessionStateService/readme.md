**Description**

This resource will provision a state service app to the local farm. Specify the name of 
the database server and database name to provision the app with, and optionally include 
the session timeout value. If session timeout is not provided it will default to 60.
